﻿#include<stdio.h>
#include<stdlib.h>

main(){
	int a,b;
	a = 10;
	b = 20;
}
