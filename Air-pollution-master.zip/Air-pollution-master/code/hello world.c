﻿#include<stdio.h>
#include<stdlib.h>

main(){
	printf("hello world, oh hello");
}
